"""Pure helpers for parsing public Telegram username allowlists."""
from urllib.parse import urlparse
import re

def normalize_target(raw: str) -> str | None:
    value = (raw or "").strip()
    if not value or value.startswith("#"):
        return None
    if value.startswith("@"):
        value = value[1:]
    elif value.lower().startswith(("https://t.me/", "http://t.me/", "https://www.t.me/", "http://www.t.me/")):
        value = urlparse(value).path.strip("/")
        if "/" in value:
            return None
    if re.fullmatch(r"[A-Za-z0-9_]{5,32}", value):
        return value.casefold()
    return None

def load_target_usernames(path):
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return set()
    return {value for line in lines if (value := normalize_target(line))}
