from __future__ import annotations

from pathlib import Path

from telethon import TelegramClient, errors
from sqlalchemy import select

from app.config import settings
from app.db import Session, Account


def _delivery_hint(sent_code) -> str:
    """Describe Telegram's reported code delivery type without exposing secrets."""
    code_type = getattr(sent_code, "type", None)
    name = type(code_type).__name__ if code_type is not None else "Unknown"
    hints = {
        "SentCodeTypeApp": "Telegram app message on an already logged-in device",
        "SentCodeTypeSms": "SMS text message",
        "SentCodeTypeCall": "phone call",
        "SentCodeTypeFlashCall": "flash call verification",
        "SentCodeTypeMissedCall": "missed call verification",
        "SentCodeTypeEmailCode": "email (follow Telegram's on-screen instructions)",
        "SentCodeTypeSetUpEmailRequired": "email setup required by Telegram",
        "SentCodeTypeFragmentSms": "Telegram-supported SMS delivery flow",
    }
    return hints.get(name, f"Telegram delivery type: {name}")


async def login_instance(instance_id: int):
    async with Session() as db:
        acc = (await db.execute(
            select(Account).where(Account.instance_id == instance_id)
        )).scalar_one_or_none()
        if not acc:
            print("Account record not found. Create the instance first.")
            return
        session = Path(acc.session_path)

    session.parent.mkdir(parents=True, exist_ok=True)
    client = TelegramClient(str(session), settings.api_id, settings.api_hash)
    phone = input("Phone number for the account you own/control (include country code): ").strip()
    if not phone:
        print("Login cancelled: no phone number supplied.")
        return

    login_succeeded = False
    try:
        await client.connect()
        if await client.is_user_authorized():
            me = await client.get_me()
            print(f"This session is already authenticated as @{me.username or 'no_username'}.")
        else:
            sent = await client.send_code_request(phone)
            print("Telegram accepted the login-code request.")
            print("Reported delivery method:", _delivery_hint(sent))
            print("Check Telegram's service chat on your logged-in devices; the code may not arrive by SMS.")
            code = input("Enter the Telegram login code (or press Enter to cancel): ").strip()
            if not code:
                print("Login cancelled. The account has not been marked authenticated.")
                return
            try:
                me = await client.sign_in(phone=phone, code=code)
            except errors.SessionPasswordNeededError:
                password = input("Two-step verification password: ")
                me = await client.sign_in(password=password)
            if me is None:
                me = await client.get_me()
            if me is None:
                print("Login did not return an account. Nothing was marked authenticated.")
                return

        async with Session() as db:
            acc = (await db.execute(
                select(Account).where(Account.instance_id == instance_id)
            )).scalar_one()
            acc.telegram_user_id = me.id
            acc.phone_hint = phone[-4:] if len(phone) >= 4 else ""
            acc.first_name = me.first_name or ""
            acc.username = me.username or ""
            acc.authenticated = True
            await db.commit()
        login_succeeded = True
        print(f"Authenticated instance #{instance_id}: @{me.username or 'no_username'}")
    except errors.PhoneNumberInvalidError:
        print("Telegram rejected that phone number. Check its country code and digits.")
    except errors.PhoneNumberBannedError:
        print("Telegram reports this phone number is banned; contact Telegram support.")
    except errors.PhoneCodeInvalidError:
        print("The code was rejected. Avoid repeated code requests; wait before retrying.")
    except errors.PhoneCodeExpiredError:
        print("That code expired. Request another only after checking Telegram's instructions and rate limits.")
    except errors.FloodWaitError as exc:
        print(f"Telegram rate limit: wait {exc.seconds} seconds before retrying.")
    except KeyboardInterrupt:
        print()
        print("Login interrupted. The account was not marked authenticated by this attempt.")
    except Exception as exc:
        print(f"Login failed: {type(exc).__name__}: {exc}")
    finally:
        await client.disconnect()

    if not login_succeeded:
        return

    # Sync the configured shared addlist only after successful authentication.
    try:
        from app.mtproto.addlists import sync_addlist
        await sync_addlist(instance_id)
    except Exception as exc:
        print(f"Addlist sync failed: {type(exc).__name__}: {exc}")

    try:
        from app.process_manager import start
        start(instance_id)
    except Exception as exc:
        print(f"Controller auto-start skipped: {type(exc).__name__}: {exc}")


async def replace_instance_account(instance_id: int):
    """Explicit replacement entry point for an account the operator controls."""
    return await login_instance(instance_id)
