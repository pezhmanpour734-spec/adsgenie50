"""Sync chats named by a Telegram shared-folder/addlist link without joining anything.

The shared list is only used to discover intended destinations. A chat is saved
only when the logged-in account already has it in its dialogs and Telegram
permissions show that the account can post. No join/import requests are issued.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone

from sqlalchemy import select
from telethon import TelegramClient, functions, utils
from telethon.tl.types import Channel, Chat

from app.config import settings
from app.db import Account, Destination, Session
from app.mtproto.session_lock import session_lock

DEFAULT_ADDLIST_URL = "https://t.me/addlist/WDpE-_NxRvI0OTlk"


def _slug_from_link(link: str) -> str:
    match = re.fullmatch(r"https?://t\.me/addlist/([A-Za-z0-9_-]+)(?:\?.*)?", (link or "").strip())
    if not match:
        raise ValueError("Invalid addlist URL. Expected https://t.me/addlist/<slug>")
    return match.group(1)


def _category(entity) -> str:
    if isinstance(entity, Channel):
        if getattr(entity, "forum", False):
            return "FORUMS"
        if getattr(entity, "megagroup", False):
            return "GROUPS"
        return "CHANNELS"
    if isinstance(entity, Chat):
        return "GROUPS"
    return "OTHER"


async def _can_post(client: TelegramClient, entity) -> bool:
    try:
        perms = await client.get_permissions(entity, "me")
        if isinstance(entity, Channel) and getattr(entity, "broadcast", False):
            return bool(getattr(perms, "post_messages", False))
        return bool(getattr(perms, "send_messages", True))
    except Exception:
        return False


async def _invite_peers(client: TelegramClient, slug: str):
    """Get peers advertised by the link; never import the folder or join peers."""
    result = await client(functions.chatlists.CheckChatlistInviteRequest(slug=slug))
    # `chats` contains resolved Telegram entities in invite responses, while
    # `peers` may contain only PeerChannel/PeerChat references. Prefer entities.
    peers = list(getattr(result, "chats", []) or []) or list(getattr(result, "peers", []) or [])
    # Some already-imported invite responses expose the folder filter instead.
    if not peers:
        filter_id = getattr(result, "filter_id", None)
        if filter_id is not None:
            try:
                filters = await client(functions.messages.GetDialogFiltersRequest())
                for dialog_filter in getattr(filters, "filters", []) or []:
                    if getattr(dialog_filter, "id", None) == filter_id:
                        peers = list(getattr(dialog_filter, "include_peers", []) or [])
                        break
            except Exception:
                pass
    return result, peers


async def sync_addlist(instance_id: int, link: str | None = None):
    link = (link or settings.addlist_url or DEFAULT_ADDLIST_URL).strip()
    try:
        slug = _slug_from_link(link)
    except ValueError as exc:
        print(f"Addlist sync failed: {exc}")
        return {"ok": False, "reason": "INVALID_ADDLIST", "found": 0, "eligible": 0}

    async with Session() as db:
        account = (await db.execute(select(Account).where(Account.instance_id == instance_id))).scalar_one_or_none()
    if not account or not account.authenticated:
        print("MTProto account is not authenticated. Log in to this instance first.")
        return {"ok": False, "reason": "ACCOUNT_NOT_AUTHENTICATED", "found": 0, "eligible": 0}

    client = TelegramClient(account.session_path, settings.api_id, settings.api_hash)
    async with session_lock(account.session_path):
        await client.connect()
        try:
            if not await client.is_user_authorized():
                print("MTProto session is no longer authorized. Re-login this instance.")
                return {"ok": False, "reason": "ACCOUNT_UNAUTHORIZED", "found": 0, "eligible": 0}

            invite, listed_peers = await _invite_peers(client, slug)
            # Resolve list peers to raw Telegram entity IDs. We intersect these
            # with dialogs below, so peers not already joined are never enabled.
            listed_ids: set[int] = set()
            for peer in listed_peers:
                try:
                    entity = peer if isinstance(peer, (Channel, Chat)) else await client.get_entity(peer)
                    if isinstance(entity, (Channel, Chat)):
                        marked_id = int(utils.get_peer_id(entity))
                        listed_ids.add(marked_id)
                        listed_ids.add(int(entity.id))
                except Exception:
                    continue

            dialogs = await client.get_dialogs()
            matched = []
            for dialog in dialogs:
                entity = getattr(dialog, "entity", None)
                if not isinstance(entity, (Channel, Chat)):
                    continue
                marked_id = int(utils.get_peer_id(entity))
                if marked_id in listed_ids or int(getattr(entity, "id", 0)) in listed_ids:
                    matched.append((dialog, entity, marked_id))

            # Avoid accidentally disabling unrelated manually-approved targets.
            # Only records explicitly sourced from this addlist are reconciled.
            present_ids = {marked_id for _, _, marked_id in matched}
            now = datetime.now(timezone.utc)
            added = updated = eligible = no_post = ignored = 0
            async with Session() as db:
                old_rows = (await db.execute(select(Destination).where(
                    Destination.instance_id == instance_id, Destination.source == "ADDLIST"
                ))).scalars().all()
                for row in old_rows:
                    if row.chat_id not in present_ids:
                        row.enabled = False
                        row.authorized = False
                        row.can_post = False
                        row.last_checked_at = now

                for dialog, entity, marked_id in matched:
                    category = _category(entity)
                    # This app's campaign is group/forum oriented; channels remain
                    # visible in the invite but are not activated for delivery.
                    if category not in {"GROUPS", "FORUMS"}:
                        ignored += 1
                        continue
                    can_post = await _can_post(client, entity)
                    row = (await db.execute(select(Destination).where(
                        Destination.instance_id == instance_id, Destination.chat_id == marked_id
                    ))).scalar_one_or_none()
                    if row is None:
                        row = Destination(instance_id=instance_id, chat_id=marked_id, source="ADDLIST")
                        db.add(row)
                        added += 1
                    else:
                        updated += 1
                        row.source = "ADDLIST"
                    row.title = getattr(dialog, "name", "") or getattr(entity, "title", "") or row.title or ""
                    row.username = getattr(entity, "username", "") or ""
                    row.category = category
                    row.authorized = bool(can_post)
                    row.can_post = bool(can_post)
                    row.enabled = bool(can_post)
                    row.last_checked_at = now
                    if can_post:
                        eligible += 1
                    else:
                        no_post += 1
                await db.commit()

            invite_title = getattr(invite, "title", None) or "Telegram addlist"
            listed_count = len(listed_peers)
            print(f"Addlist: {link}")
            print(f"Folder: {invite_title}")
            print(f"Listed peers: {listed_count}; already joined and matched: {len(matched)}")
            print(f"New records: {added}; refreshed: {updated}; postable Groups/Forums: {eligible}; no posting permission: {no_post}; ignored non-group chats: {ignored}")
            print("No chats were joined or imported automatically.")
            return {"ok": True, "reason": "COMPLETE", "found": len(matched), "eligible": eligible, "added": added, "updated": updated, "no_post": no_post}
        except Exception as exc:
            print(f"Addlist sync failed: {type(exc).__name__}: {exc}")
            return {"ok": False, "reason": type(exc).__name__, "found": 0, "eligible": 0}
        finally:
            await client.disconnect()
