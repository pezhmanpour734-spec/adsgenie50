import asyncio
import logging
import os
import re
from html import escape
from datetime import datetime, timezone

from aiogram import Bot, Dispatcher, Router, F
from aiogram.exceptions import TelegramRetryAfter
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from sqlalchemy import select
from telethon import functions

from app.config import settings
from app.db import Session, Instance, Campaign, Account
from app.services.campaigns import load_campaign, destination_counts, set_target_category, run_campaign_once, set_campaign_active
from app.mtproto.session_lock import session_lock

log = logging.getLogger(__name__)


class CampaignStates(StatesGroup):
    waiting_post_link = State()


class ProfileStates(StatesGroup):
    waiting_name = State()
    waiting_username = State()
    waiting_bio = State()
    waiting_photo = State()


def is_admin(user_id: int) -> bool:
    return int(user_id) == int(settings.admin_chat_id)


def customer_allowed(user_id: int, inst: Instance) -> bool:
    return int(user_id) == int(inst.customer_chat_id or 0)


def post_link_is_valid(link: str) -> bool:
    return bool(re.fullmatch(
        r"https?://t\.me/(?:c/\d+|[A-Za-z0-9_]{4,})/\d+(?:\?[^\s]+)?",
        link.strip(), flags=re.IGNORECASE
    ))


def _html_link(label: str, url: str | None) -> str:
    if not url:
        return escape(str(label))
    return f'<a href="{escape(url, quote=True)}">{escape(str(label))}</a>'


def admin_profile_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✏️ Change Name", callback_data="profile_name")],
        [InlineKeyboardButton(text="🔤 Change Username", callback_data="profile_username")],
        [InlineKeyboardButton(text="📝 Change Bio", callback_data="profile_bio")],
        [InlineKeyboardButton(text="🖼 Change Profile Photo", callback_data="profile_photo")],
        [InlineKeyboardButton(text="🔄 View Current Profile", callback_data="profile_refresh")],
    ])



async def latest_campaign(instance_id: int):
    return await load_campaign(instance_id)


async def save_log_chat(inst_id: int, chat_id: int, title: str = "", link: str = ""):
    async with Session() as s:
        inst = await s.get(Instance, inst_id)
        if inst:
            inst.log_chat_id = int(chat_id)
            inst.log_chat_title = title[:255]
            inst.log_chat_link = link[:1000] if link else None
            await s.commit()


async def emit_log(bot: Bot, inst: Instance, text: str, view_link: str | None = None):
    # Fast path: every controller already keeps its per-instance Logs channel ID
    # in memory. Only hit SQLite when the cached value is missing. This matters
    # when many independent controllers are running on a small VPS.
    chat_id = inst.log_chat_id
    if not chat_id:
        async with Session() as s:
            fresh = await s.get(Instance, inst.id)
            chat_id = fresh.log_chat_id if fresh else None
            if fresh and fresh.log_chat_id:
                inst.log_chat_id = fresh.log_chat_id
                inst.log_chat_link = fresh.log_chat_link
    if not chat_id:
        return False
    markup = None
    if view_link:
        markup = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="👁 View Message", url=view_link)
        ]])
    try:
        await bot.send_message(
            chat_id, text, parse_mode="HTML", disable_web_page_preview=True,
            reply_markup=markup,
        )
        return True
    except TelegramRetryAfter as exc:
        # A Logs-channel Bot API rate limit must NEVER become a campaign
        # delivery failure. Do not sleep inside the forwarding loop; record it
        # locally and let the next delivery continue.
        retry_after = max(1, int(getattr(exc, "retry_after", 1)))
        log.warning(
            "Logs channel rate-limited for #%02d (%ss); delivery continues without waiting.",
            inst.id, retry_after,
        )
        return False
    except Exception as exc:
        log.warning("Log channel send failed for #%02d: %s", inst.id, exc)
        return False


async def _verify_log_bot(bot: Bot, chat_id: int, bot_id: int):
    """Verify that the controller bot is actually an administrator who can post."""
    member = await bot.get_chat_member(chat_id, bot_id)
    status = getattr(member, "status", "")
    if status != "administrator":
        return False, f"bot membership status is {status!r}"
    if hasattr(member, "can_post_messages") and member.can_post_messages is False:
        return False, "bot administrator has can_post_messages=False"
    return True, "ok"


async def _private_log_link(bot: Bot, chat_id: int, instance_id: int):
    """Create a reusable private invite link after Bot API access is verified."""
    try:
        return await bot.export_chat_invite_link(chat_id)
    except Exception as exc:
        log.warning("Could not create logs invite link for #%02d: %s", instance_id, exc)
        return ""


async def ensure_log_channel(inst: Instance, bot: Bot, bot_username: str, bot_id: int):
    """Ensure a real, postable per-instance Logs channel exists."""
    from telethon import TelegramClient, functions, types, utils

    async with Session() as s:
        acc = (await s.execute(select(Account).where(Account.instance_id == inst.id))).scalar_one_or_none()
    if not acc or not acc.authenticated:
        raise RuntimeError("linked MTProto account is not authenticated")
    if not bot_username:
        raise RuntimeError("controller bot has no username; cannot identify the controller bot")

    client = TelegramClient(acc.session_path, settings.api_id, settings.api_hash)
    async with session_lock(acc.session_path):
        await client.connect()
        try:
            if not await client.is_user_authorized():
                raise RuntimeError("linked MTProto account is not authorized")

            channel = None
            if inst.log_chat_id:
                try:
                    raw_id, peer_type = utils.resolve_id(int(inst.log_chat_id))
                    if peer_type.__name__ == "PeerChannel":
                        channel = await client.get_entity(types.PeerChannel(raw_id))
                except Exception as exc:
                    log.warning("Saved logs channel could not be opened for #%02d: %s", inst.id, exc)

            if channel is None:
                wanted_title = f"AdsGenie Logs #{inst.id:02d}"
                try:
                    for dialog in await client.get_dialogs():
                        entity = dialog.entity
                        if (isinstance(entity, types.Channel)
                                and bool(getattr(entity, "broadcast", False))
                                and getattr(entity, "title", "") == wanted_title):
                            channel = entity
                            break
                except Exception as exc:
                    log.warning("Could not scan for orphan logs channel #%02d: %s", inst.id, exc)

            if channel is None:
                result = await client(functions.channels.CreateChannelRequest(
                    title=f"AdsGenie Logs #{inst.id:02d}",
                    about=f"Delivery logs for {inst.name}",
                    broadcast=True,
                    megagroup=False,
                ))
                channel = result.chats[0]

            bot_entity = await client.get_input_entity("@" + bot_username.lstrip("@"))
            try:
                await client.edit_admin(
                    channel,
                    bot_entity,
                    post_messages=True,
                    invite_users=True,
                    title="AdsGenie",
                )
            except Exception as exc:
                raise RuntimeError("could not add/promote controller bot as channel admin: " + str(exc)) from exc

            bot_chat_id = int(f"-100{channel.id}")
            title = getattr(channel, "title", None) or f"AdsGenie Logs #{inst.id:02d}"
            ok, reason = await _verify_log_bot(bot, bot_chat_id, bot_id)
            if not ok:
                raise RuntimeError(f"logs channel bot permission verification failed: {reason}")

            link = await _private_log_link(bot, bot_chat_id, inst.id)
            # Do not mark READY until the actual Bot API write succeeds.
            await bot.send_message(
                bot_chat_id,
                f"🟢 <b>LOGS READY</b>\nInstance: #{inst.id:02d}\nController: @{bot_username}\n\nThis channel receives AdsGenie delivery logs.",
                parse_mode="HTML",
                disable_web_page_preview=True,
            )
            await save_log_chat(inst.id, bot_chat_id, title, link)
            return bot_chat_id, title, link
        finally:
            await client.disconnect()


async def repair_logs_channel(instance_id: int):
    """CLI/admin helper: create or repair the instance Logs channel and verify it."""
    await __import__("app.db", fromlist=["init_db"]).init_db()
    async with Session() as s:
        inst = await s.get(Instance, instance_id)
    if not inst:
        raise RuntimeError(f"instance #{instance_id} not found")
    bot = Bot(inst.bot_token)
    try:
        me = await bot.get_me()
        chat_id, title, link = await ensure_log_channel(inst, bot, me.username or "", me.id)
        return {"chat_id": chat_id, "title": title, "link": link}
    finally:
        await bot.session.close()


async def run_controller(instance_id: int):
    from app.db import init_db
    await init_db()

    async with Session() as s:
        inst = await s.get(Instance, instance_id)
    if not inst:
        print(f"Controller #{instance_id:02d}: instance not found.")
        return
    if not inst.bot_token or ":" not in inst.bot_token:
        print(f"Controller #{instance_id:02d}: invalid/missing BotFather token.")
        return

    try:
        bot = Bot(inst.bot_token)
    except Exception as exc:
        print(f"Controller #{instance_id:02d}: BotFather token rejected: {type(exc).__name__}: {exc}")
        print("Use CLI option 12 to replace the bot token with a valid BotFather token.")
        return
    dp = Dispatcher(storage=MemoryStorage())
    router = Router()
    dp.include_router(router)
    campaign_task = None
    logs_repair_task = None

    async def guard_customer(message: Message) -> bool:
        if not message.from_user:
            return False
        async with Session() as s:
            fresh = await s.get(Instance, inst.id)
        if not fresh or int(message.from_user.id) != int(fresh.customer_chat_id or 0):
            await message.answer("⛔ This controller is not assigned to you.")
            return False
        if fresh.disabled:
            await message.answer("🔴 <b>ACCESS DISABLED</b>\n\nPlease contact the administrator.", parse_mode="HTML")
            return False
        until = fresh.validity_until
        if until is None:
            await message.answer("⚠️ <b>VALIDITY NOT CONFIGURED</b>\n\nPlease contact the administrator.", parse_mode="HTML")
            return False
        if until.tzinfo is None:
            until = until.replace(tzinfo=timezone.utc)
        now = datetime.now(timezone.utc)
        if until <= now:
            await message.answer(
                "🔴 <b>ACCESS EXPIRED</b>\n\nYour controller access has expired.\nPlease contact the administrator for renewal.",
                parse_mode="HTML"
            )
            return False
        return True

    async def guard_admin(message: Message) -> bool:
        if not message.from_user or not is_admin(message.from_user.id):
            await message.answer("⛔ Admin only.")
            return False
        return True

    async def campaign_loop():
        while True:
            async with Session() as s:
                fresh = await s.get(Instance, inst.id)
            if not fresh or fresh.state != "RUNNING":
                return
            result = await run_campaign_once(
                inst.id, bot,
                lambda text, view_link=None: emit_log(bot, inst, text, view_link),
                category="GROUPS_FORUMS",
            )
            if result["reason"] != "DONE":
                await emit_log(bot, inst, f"⚠️ <b>AD CYCLE STOPPED</b>\nInstance: #{inst.id:02d}\nReason: <code>{result['reason']}</code>")
                await set_campaign_active(inst.id, False)
                return
            # A complete authorized-target cycle gets the configured cooldown.
            # /stop changes DB state, and the sleep is cancellable by task cancel.
            await asyncio.sleep(settings.batch_cooldown_seconds)

    async def logs_repair_loop(bot_username: str, bot_id: int):
        """Keep trying Logs setup until it is genuinely usable."""
        while True:
            try:
                async with Session() as s:
                    fresh = await s.get(Instance, inst.id)
                if fresh and fresh.log_chat_link:
                    return
                await ensure_log_channel(inst, bot, bot_username, bot_id)
                print(f"Controller #{instance_id:02d}: Logs self-repair succeeded.")
                return
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                print(f"Controller #{instance_id:02d}: Logs retry: {type(exc).__name__}: {exc}")
                await asyncio.sleep(30)

    try:
        me = await bot.get_me()
        print(f"Controller #{instance_id:02d} started as @{me.username or me.first_name}")
        await bot.delete_webhook(drop_pending_updates=False)

        # Create/repair the per-instance logs channel automatically.
        try:
            chat_id, title, log_link = await ensure_log_channel(inst, bot, me.username or "", me.id)
            print(f"Controller #{instance_id:02d}: LOGS READY -> {log_link or chat_id}")
        except Exception as exc:
            print(f"Controller #{instance_id:02d}: LOGS NOT READY: {type(exc).__name__}: {exc}")
            logs_repair_task = asyncio.create_task(logs_repair_loop(me.username or "", me.id))

        @router.message(Command("start"))
        async def cmd_start(message: Message):
            nonlocal campaign_task
            if is_admin(message.from_user.id):
                await message.answer(
                    f"👤 <b>AdsGenie — Linked Account</b>\n\nInstance: <code>#{inst.id:02d}</code>\n"
                    "Use the buttons below to edit the logged-in MTProto account.",
                    parse_mode="HTML", reply_markup=admin_profile_menu()
                )
                return
            if not await guard_customer(message):
                return
            campaign = await latest_campaign(inst.id)
            if not campaign or not campaign.source_link:
                await message.answer(
                    "📌 <b>AD NOT CONFIGURED</b>\n\n"
                    "First send <code>/change</code> and provide the Telegram post link.\n"
                    "Then send <code>/start</code> to start Groups + Forums together.",
                    parse_mode="HTML"
                )
                return
            counts = await destination_counts(inst.id)
            total = counts["GROUPS"] + counts["FORUMS"]
            if total <= 0:
                await message.answer(
                    "⚠️ <b>NO GROUPS OR FORUMS</b>\n\n"
                    "Run <code>4. Sync approved targets</code> first, then send /start again.",
                    parse_mode="HTML"
                )
                return
            if campaign_task and not campaign_task.done():
                await message.answer("🟢 <b>Ads are already running.</b>\n\nUse /stop to stop the campaign.", parse_mode="HTML")
                return

            # One combined queue: Groups + Forums. No target selection UI.
            await set_target_category(inst.id, "GROUPS_FORUMS")
            await set_campaign_active(inst.id, True)
            inst.state = "RUNNING"
            campaign_task = asyncio.create_task(campaign_loop())

            async with Session() as s:
                fresh = await s.get(Instance, inst.id)
                logs_link = fresh.log_chat_link if fresh else inst.log_chat_link
            logs_text = escape(logs_link) if logs_link else "Logs channel is being repaired in the background."
            async with Session() as s:
                account_for_log = (await s.execute(select(Account).where(Account.instance_id == inst.id))).scalar_one_or_none()
            by_id = account_for_log.telegram_user_id if account_for_log and account_for_log.telegram_user_id else "-"
            source_html = _html_link(campaign.source_link, campaign.source_link)
            await emit_log(
                bot, inst,
                f"🚀 <b>Forwarding Started!</b>\n"
                f"By: <code>{escape(str(by_id))}</code>\n"
                f"Source: {source_html}"
            )
            await message.answer(
                f"🟢 <b>ADSGENIE STARTED</b>\n\n"
                f"📨 Queue: <b>Groups + Forums</b>\n"
                f"👥 Groups: <code>{counts['GROUPS']}</code>\n"
                f"💬 Forums: <code>{counts['FORUMS']}</code>\n"
                f"📊 Total: <code>{total}</code>\n"
                f"📝 Logs: {logs_text}\n\n"
                "No target selection is required. The combined queue is running now.",
                parse_mode="HTML"
            )

        @router.message(Command("help"))
        async def cmd_help(message: Message):
            if is_admin(message.from_user.id):
                await message.answer("Use /start here for the linked account profile controls.", parse_mode="HTML")
                return
            if not await guard_customer(message): return
            async with Session() as s:
                fresh = await s.get(Instance, inst.id)
                logs_link = fresh.log_chat_link if fresh else inst.log_chat_link
            await message.answer(
                "<b>Ads Controller</b>\n\n"
                "/start — start Groups + Forums together\n"
                "/stop — stop ads\n"
                "/validity — subscription validity\n"
                "/change — set/change Telegram post\n"
                "/ping — controller health\n"
                "/help — show this help\n\n"
                f"📝 <b>Logs:</b> {logs_link or 'Not ready — admin must repair Logs.'}",
                parse_mode="HTML"
            )

        @router.message(Command("ping"))
        async def cmd_ping(message: Message):
            if not await guard_customer(message): return
            async with Session() as s: fresh = await s.get(Instance, inst.id)
            logs_link = fresh.log_chat_link if fresh else inst.log_chat_link
            await message.answer(f"🏓 <b>PONG</b>\nState: <code>{fresh.state if fresh else inst.state}</code>\nLogs: {logs_link or 'not ready'}", parse_mode="HTML")

        @router.message(Command("validity"))
        async def cmd_validity(message: Message):
            if not await guard_customer(message): return
            async with Session() as s: fresh = await s.get(Instance, inst.id)
            value = fresh.validity_until if fresh else inst.validity_until
            if value and value.tzinfo is None:
                value = value.replace(tzinfo=timezone.utc)
            if not value:
                await message.answer("⏳ <b>VALIDITY</b>\n\n⚠️ Not configured.", parse_mode="HTML")
                return
            remaining = max(0, int((value - datetime.now(timezone.utc)).total_seconds()))
            if remaining <= 0:
                status = "🔴 EXPIRED"
                remaining_text = "0 days 0 hours"
            else:
                status = "🟢 ACTIVE"
                remaining_text = f"{remaining // 86400} days {(remaining % 86400) // 3600} hours"
            await message.answer(
                f"⏳ <b>VALIDITY</b>\n\n{status}\n\n"
                f"Remaining: <code>{remaining_text}</code>\n"
                f"Expires: <code>{value.astimezone().strftime('%d %b %Y %H:%M %Z')}</code>",
                parse_mode="HTML"
            )

        @router.message(Command("stop"))
        async def cmd_stop(message: Message):
            nonlocal campaign_task
            if not await guard_customer(message): return
            if campaign_task and not campaign_task.done():
                campaign_task.cancel()
                try: await campaign_task
                except asyncio.CancelledError: pass
            campaign_task = None
            await set_campaign_active(inst.id, False)
            inst.state = "STOPPED"
            await emit_log(bot, inst, f"⏹ <b>ADS STOPPED</b>\nInstance: #{inst.id:02d}")
            await message.answer("⏹ <b>Ads stopped.</b>", parse_mode="HTML")

        @router.message(Command("change"))
        async def cmd_change(message: Message, state: FSMContext):
            if not await guard_customer(message): return
            await state.set_state(CampaignStates.waiting_post_link)
            current = await latest_campaign(inst.id)
            await message.answer(
                "📌 <b>CHANGE AD</b>\n\nSend the Telegram channel post link.\n\n"
                "Example: <code>https://t.me/channel/123</code>\n\n"
                f"Current: <code>{current.source_link if current else 'Not set'}</code>", parse_mode="HTML"
            )

        @router.message(CampaignStates.waiting_post_link)
        async def receive_post_link(message: Message, state: FSMContext):
            if not await guard_customer(message):
                await state.clear(); return
            link = (message.text or message.caption or "").strip()
            if not post_link_is_valid(link):
                await message.answer("❌ Invalid Telegram post link. Use <code>https://t.me/channel/123</code>.", parse_mode="HTML")
                return
            async with Session() as s:
                result = await s.execute(select(Campaign).where(Campaign.instance_id == inst.id).order_by(Campaign.id.desc()).limit(1))
                campaign = result.scalar_one_or_none()
                if campaign:
                    campaign.text = link; campaign.source_link = link; campaign.active = False; campaign.updated_at = datetime.now(timezone.utc)
                else:
                    s.add(Campaign(instance_id=inst.id, text=link, source_link=link, active=False, target_category="ALL", updated_at=datetime.now(timezone.utc)))
                x = await s.get(Instance, inst.id)
                if x: x.state = "STOPPED"
                await s.commit()
            await state.clear()
            await emit_log(bot, inst, f"📌 <b>POST CHANGED</b>\nInstance: #{inst.id:02d}\nPost: <code>{link}</code>")
            await message.answer("✅ <b>Post updated.</b>\n\nSend /start to start Groups + Forums together.", parse_mode="HTML")

        # ---------------- ADMIN PROFILE ONLY ----------------
        @router.message(Command("profile"))
        async def cmd_profile(message: Message):
            if not await guard_admin(message): return
            await message.answer(
                f"👤 <b>Linked Account Profile</b>\n\nInstance: <code>#{inst.id:02d}</code>",
                parse_mode="HTML", reply_markup=admin_profile_menu()
            )

        @router.callback_query(F.data.startswith("profile_"))
        async def profile_callback(callback: CallbackQuery, state: FSMContext):
            if not is_admin(callback.from_user.id):
                await callback.answer("Admin only.", show_alert=True); return
            await callback.answer()
            action = callback.data
            if action == "profile_name":
                await state.set_state(ProfileStates.waiting_name); await callback.message.answer("Send the new first name for the linked MTProto account.")
            elif action == "profile_username":
                await state.set_state(ProfileStates.waiting_username); await callback.message.answer("Send the new username without @.")
            elif action == "profile_bio":
                await state.set_state(ProfileStates.waiting_bio); await callback.message.answer("Send the new bio/about text.")
            elif action == "profile_photo":
                await state.set_state(ProfileStates.waiting_photo); await callback.message.answer("Send the new profile photo as an image.")
            elif action == "profile_refresh":
                client = None
                try:
                    async with Session() as s:
                        acc = (await s.execute(select(Account).where(Account.instance_id == inst.id))).scalar_one_or_none()
                    if not acc or not acc.authenticated:
                        await callback.message.answer("❌ Linked MTProto account is not authenticated.")
                        return
                    async with session_lock(acc.session_path):
                        client = await get_mtproto_client(inst.id)
                        if not client:
                            await callback.message.answer("❌ Linked MTProto account is not authenticated.")
                            return
                        try:
                            me = await client.get_me()
                            await callback.message.answer(
                                f"👤 <b>Current MTProto Profile</b>\n\n"
                                f"Name: <code>{escape(((me.first_name or '') + ' ' + (me.last_name or '')).strip() or '-')}</code>\n"
                                f"Username: <code>@{escape(me.username or '-')}</code>\n"
                                f"User ID: <code>{me.id}</code>", parse_mode="HTML", reply_markup=admin_profile_menu()
                            )
                        finally:
                            await client.disconnect()
                except Exception as exc:
                    await callback.message.answer(f"❌ {type(exc).__name__}: {escape(str(exc))}", parse_mode="HTML")

        async def get_mtproto_client(instance_id: int):
            from telethon import TelegramClient
            async with Session() as s:
                acc = (await s.execute(select(Account).where(Account.instance_id == instance_id))).scalar_one_or_none()
            if not acc or not acc.authenticated: return None
            client = TelegramClient(acc.session_path, settings.api_id, settings.api_hash)
            await client.connect()
            if not await client.is_user_authorized():
                await client.disconnect(); return None
            return client

        async def _account_session_path(instance_id: int):
            async with Session() as s:
                acc = (await s.execute(select(Account).where(Account.instance_id == instance_id))).scalar_one_or_none()
            if not acc or not acc.authenticated:
                raise RuntimeError("Linked MTProto account is not authenticated")
            return acc.session_path

        async def _sync_account_profile(instance_id: int, me):
            async with Session() as s:
                row = (await s.execute(select(Account).where(Account.instance_id == instance_id))).scalar_one_or_none()
                if row:
                    row.telegram_user_id = me.id
                    row.first_name = me.first_name or ""
                    row.username = me.username or ""
                    row.bio = getattr(me, "about", "") or ""
                    await s.commit()

        async def _profile_client(instance_id: int):
            client = await get_mtproto_client(instance_id)
            if not client:
                raise RuntimeError("Linked MTProto account is not authenticated")
            return client

        @router.message(ProfileStates.waiting_name)
        async def profile_name(message: Message, state: FSMContext):
            if not await guard_admin(message):
                await state.clear(); return
            client = None
            try:
                value = (message.text or "").strip()
                if not value:
                    await message.answer("❌ Name cannot be empty."); return
                parts = value.split(maxsplit=1)
                session_path = await _account_session_path(inst.id)
                async with session_lock(session_path):
                    client = await _profile_client(inst.id)
                    await client(functions.account.UpdateProfileRequest(
                        first_name=parts[0], last_name=parts[1] if len(parts) > 1 else ""
                    ))
                    me = await client.get_me()
                    expected_last = parts[1] if len(parts) > 1 else ""
                    if (me.first_name or "") != parts[0] or (me.last_name or "") != expected_last:
                        raise RuntimeError("Telegram did not confirm the new name")
                    await _sync_account_profile(inst.id, me)
                await message.answer("✅ Name updated and verified.")
            except Exception as exc:
                await message.answer(f"❌ {type(exc).__name__}: {escape(str(exc))}", parse_mode="HTML")
            finally:
                if client:
                    await client.disconnect()
                await state.clear()

        @router.message(ProfileStates.waiting_username)
        async def profile_username(message: Message, state: FSMContext):
            if not await guard_admin(message):
                await state.clear(); return
            client = None
            try:
                value = (message.text or "").strip().lstrip("@")
                if not re.fullmatch(r"[A-Za-z0-9_]{5,32}", value):
                    await message.answer("❌ Invalid username format."); return
                session_path = await _account_session_path(inst.id)
                async with session_lock(session_path):
                    client = await _profile_client(inst.id)
                    me = await client(functions.account.UpdateUsernameRequest(username=value))
                    if (getattr(me, "username", "") or "").lower() != value.lower():
                        raise RuntimeError("Telegram did not confirm the new username")
                    await _sync_account_profile(inst.id, me)
                await message.answer(f"✅ Username updated to @{escape(value)} and verified.", parse_mode="HTML")
            except Exception as exc:
                await message.answer(f"❌ {type(exc).__name__}: {escape(str(exc))}", parse_mode="HTML")
            finally:
                if client:
                    await client.disconnect()
                await state.clear()

        @router.message(ProfileStates.waiting_bio)
        async def profile_bio(message: Message, state: FSMContext):
            if not await guard_admin(message):
                await state.clear(); return
            client = None
            try:
                value = (message.text or "").strip()
                session_path = await _account_session_path(inst.id)
                async with session_lock(session_path):
                    client = await _profile_client(inst.id)
                    await client(functions.account.UpdateProfileRequest(about=value))
                    me = await client.get_me()
                    if (getattr(me, "about", "") or "") != value:
                        raise RuntimeError("Telegram did not confirm the new bio")
                    await _sync_account_profile(inst.id, me)
                await message.answer("✅ Bio updated and verified.")
            except Exception as exc:
                await message.answer(f"❌ {type(exc).__name__}: {escape(str(exc))}", parse_mode="HTML")
            finally:
                if client:
                    await client.disconnect()
                await state.clear()

        @router.message(ProfileStates.waiting_photo, F.photo)
        async def profile_photo(message: Message, state: FSMContext):
            if not await guard_admin(message):
                await state.clear(); return
            client = None; temp = None
            try:
                temp = os.path.join(settings.session_dir, f"profile_{inst.id}.jpg")
                session_path = await _account_session_path(inst.id)
                async with session_lock(session_path):
                    client = await _profile_client(inst.id)
                    await bot.download(message.photo[-1], destination=temp)
                    uploaded = await client.upload_file(temp)
                    await client(functions.photos.UploadProfilePhotoRequest(file=uploaded))
                    photos = await client.get_profile_photos("me", limit=1)
                    if not photos:
                        raise RuntimeError("Telegram did not confirm the new profile photo")
                await message.answer("✅ Profile photo updated and verified.")
            except Exception as exc:
                await message.answer(f"❌ {type(exc).__name__}: {escape(str(exc))}", parse_mode="HTML")
            finally:
                if temp:
                    try: os.remove(temp)
                    except OSError: pass
                if client:
                    await client.disconnect()
                await state.clear()

        @router.message(ProfileStates.waiting_photo)
        async def profile_photo_invalid(message: Message, state: FSMContext):
            if await guard_admin(message): await message.answer("Send an image/photo.")
            await state.clear()

        # Resume a campaign that was explicitly left RUNNING across a controller/VPS restart.
        async with Session() as s:
            fresh_start = await s.get(Instance, inst.id)
            resume_campaign = bool(fresh_start and fresh_start.state == "RUNNING")
        if resume_campaign and campaign_task is None:
            latest = await latest_campaign(inst.id)
            if latest and latest.active and latest.source_link:
                await set_target_category(inst.id, "GROUPS_FORUMS")
                campaign_task = asyncio.create_task(campaign_loop())
                print(f"Controller #{instance_id:02d}: resumed RUNNING campaign after restart.")

        print(f"Controller #{instance_id:02d}: polling... customer={inst.customer_chat_id}")
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    except Exception as exc:
        log.exception("Controller #%02d crashed", instance_id)
        print(f"Controller #{instance_id:02d} crashed: {type(exc).__name__}: {exc}")
        raise
    finally:
        if campaign_task and not campaign_task.done():
            campaign_task.cancel()
            try: await campaign_task
            except asyncio.CancelledError: pass
        if logs_repair_task and not logs_repair_task.done():
            logs_repair_task.cancel()
            try: await logs_repair_task
            except asyncio.CancelledError: pass
        await bot.session.close()
