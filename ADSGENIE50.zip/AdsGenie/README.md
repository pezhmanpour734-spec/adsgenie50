# AdsGenie — Clean Build

This archive is a clean source package: no real credentials, `.env`, session files, database, runtime logs, cached bytecode, or active per-instance blacklist data are included. Runtime dependencies are kept in `requirements.txt`; test-only dependency `pytest` is in `requirements-dev.txt`.

**Core features retained:** multi-instance management, Telegram account login, sync of destinations already joined, permission/paid-message preflight and persistent blacklist, campaign source setup, controlled queue pacing, controller status/logs, validity management, and profile updates. Manual Join List and local-file join-review options have been removed to keep the CLI focused. The app works with destinations already joined by the account and checks posting permissions before delivery.

# AdsGenie — Instance Management Update

This build keeps the existing campaign, forum-topic, permissions, Logs, pacing, and View Message functionality and adds administrator-side instance management.

## CLI: Edit instance

Run:

```text
python run.py
```

Choose:

```text
12. Edit instance / token / Chat ID / validity
16. Delete an instance (explicit confirmation required)
```

Available actions:

1. Change bot token — validates the new BotFather token with Telegram **before** saving it. If the controller is running, it is stopped so it cannot keep using the old token.
2. Change customer Chat ID — updates the customer allowed to operate that instance.
3. Change instance name.
4. Assign / renew validity.
5. Disable instance.
6. Enable instance.
7. Show current data.

## Validity plans

Built-in plans:

- 7 days
- 30 days
- 45 days
- 60 days
- 90 days
- 180 days
- 365 days
- Custom 1–3650 days

When assigning validity, choose whether to set it from now or extend the existing expiration.

Customer access is checked against the **current database record** on every controller request. Disabled and expired customers are rejected. `/validity` shows active/expired status, remaining days/hours, and the expiration timestamp.

## Bot token errors

A bad token can no longer be saved through the CLI. Controller startup also catches malformed BotFather tokens and prints a clean repair instruction instead of a Python traceback.

## Safety

Account replacement remains CLI/instance-only. No controller command exposes account replacement.


## AdsGenie campaign behavior

- `/start` starts **Groups + Forums together**. There is no target-selection prompt.
- Controllers can be managed by systemd so they stay online after logout and automatically restart after a VPS reboot.
- The campaign reads the already-synced authorized destinations and runs one combined queue.
- A Logs-channel Bot API rate limit is isolated from delivery; it is recorded locally and does not stop the forwarding loop.
- A Telegram MTProto `FloodWait` is treated as a rate-limit event, not a fatal controller crash. AdsGenie waits the server-requested time and then continues the queue.
- Delivery logs include per-target success/error details, flood-wait recovery, and View Message when Telegram provides a link. Routine cycle-complete and cooldown notices are intentionally silent; configured delays and automatic resume behavior are preserved.
- Admins can use `/start` or `/profile` on a controller to change the linked MTProto account's name, username, bio, and profile photo.

## Lightweight multi-instance operation

The default configured instance ceiling is **40**. The controller keeps destination filtering out of the runtime path and avoids an idle Telethon connection per account; MTProto connections are opened only for delivery/profile operations. SQLite is configured with WAL and a busy timeout for concurrent controller processes.

This is an engineering target, not a guarantee that every VPS can run 40 accounts: actual capacity depends on RAM, CPU, Telegram traffic, destination count, and VPS limits. For a small VPS, start with 20 and scale upward while watching RAM/CPU. PostgreSQL is preferable when the installation becomes heavily concurrent.


## Destination safety filter

This build does **not** auto-join arbitrary Telegram groups from a username list. It only works with destinations the MTProto account already belongs to. The filter checks posting permission and Telegram Stars paid-message requirements; definitive ineligible destinations are disabled and saved per instance under `runtime/blacklist/instance_XX.json`. Temporary/network errors are not blacklisted and no Telegram Stars are spent.

The configured shared addlist defaults to `https://t.me/addlist/WDpE-_NxRvI0OTlk` (`ADDLIST_URL` in `.env`). Option **4** inspects that list and syncs only Groups/Forums already joined by the logged-in account, checking posting permissions. It does not import the folder or join any chats. Option **15** runs the addlist sync and then checks saved destinations for posting rights and paid-message restrictions. Option **14** filters existing database destinations only. Destinations that were previously sourced from the addlist but are no longer present/matched are disabled; unrelated manual destinations are not touched.

Forum delivery prefers an existing open topic whose title contains **Instagram**, then the General topic, then the first available open topic. It does not create topics, auto-join chats, or send probe messages. If a destination is not joined, is inaccessible, or the account lacks posting rights, it will not be force-enabled.

If you have an authorized target list, join/approve those destinations in Telegram first, then run the sync/filter flow.

## Fresh install

This archive intentionally contains no database, sessions, runtime logs, active blacklist entries, or real credentials. Blacklist files are created automatically only when a destination is definitively ineligible. Copy `.env.example` to `.env` and enter your own settings. The default empty database is `data/adsgenie.db`.

## 24/7 controllers

Install the included systemd template on the VPS:

```bash
cd /opt/adsgenie/AdsGenie
sudo ./scripts/install_systemd.sh
```

Then enable an instance:

```bash
sudo systemctl enable --now adsgenie-instance@1
```

The controller starts without an interactive terminal, restarts on failure, and starts again after a VPS reboot. The campaign itself resumes only when the database says the instance was explicitly left in `RUNNING` state.

## Preflight and target-list troubleshooting

1. Copy `.env.example` to `.env` and set valid `API_ID`, `API_HASH`, `ADMIN_CHAT_ID`, and any required controller settings.
2. Authenticate the instance with menu option **3**.
3. Use menu option **15** to sync the bundled allowlist and filter existing joined destinations.
4. Read the terminal output: `OK` means a joined chat was found and posting permission was detected; `SKIP` identifies a saved blacklist or no-post permission; `Not joined / not found` lists handles that the account cannot currently resolve from its joined dialogs.
5. Set the campaign source link with option **6**, then start the controller with option **5**.

The older `targets.txt` file is retained for compatibility but is not used by the normal sync flow. The active sync source is the configured Telegram shared addlist. A destination is considered only when it appears in that list and the account already has it in its dialogs; the app never auto-joins chats. Forum preflight checks open topics and prefers an open topic with “Instagram” in its title.

## Test suite

Run `python -m compileall -q app tests run.py` and `python -m pytest -q` in the project virtual environment. The included tests cover pacing/log-link code contracts, allowlist normalization, combined target uniqueness, and Instagram-topic selection/fallbacks.

## Destination waitlist and retry behavior

- Destination-specific Telegram slow-mode limits are saved in the `queue_jobs` table as `WAITLIST` records with a UTC retry deadline and attempt count.
- A slow-mode-limited destination is skipped temporarily while the campaign continues with other eligible destinations.
- When a retry deadline has passed, that destination becomes eligible on a later campaign pass; a successful/attempted retry clears the previous waitlist record before delivery.
- If all otherwise-eligible destinations are temporarily waitlisted, the controller reports a completed empty pass rather than stopping itself.
- Account-wide Telegram `FloodWaitError` is different: the client waits for Telegram's required account-level delay before continuing. This is respected rather than bypassed.
- Existing one-minute pacing and the configured batch/cycle cooldown remain in place.

On SQLite installations, startup adds the `queue_jobs.retry_at` column to an existing database automatically. Keep your current `.env`, database, and `sessions/` directory when upgrading; this ZIP intentionally excludes secrets, local database files, and Telegram session files.
