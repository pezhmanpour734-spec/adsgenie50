Operational scripts are intentionally Python-only.
Use:
python run.py
python run.py preflight
python run.py db-init
python run.py login --instance 1
python run.py sync --instance 1
python run.py bot --instance 1
