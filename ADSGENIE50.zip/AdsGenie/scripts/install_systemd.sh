#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="/opt/adsgenie/AdsGenie"
VENV_PYTHON="/opt/adsgenie/.venv/bin/python"
UNIT_SRC="$PROJECT_ROOT/systemd/adsgenie-instance@.service"
UNIT_DST="/etc/systemd/system/adsgenie-instance@.service"

if [[ ! -x "$VENV_PYTHON" ]]; then
  echo "Missing Python venv: $VENV_PYTHON"
  exit 1
fi
if [[ ! -f "$UNIT_SRC" ]]; then
  echo "Missing unit file: $UNIT_SRC"
  exit 1
fi

install -m 0644 "$UNIT_SRC" "$UNIT_DST"
systemctl daemon-reload

echo "AdsGenie systemd template installed."
echo "Enable an instance with: systemctl enable --now adsgenie-instance@1"
echo "Check it with:          systemctl status adsgenie-instance@1 --no-pager"
