from pathlib import Path


def test_slow_mode_uses_persistent_waitlist_and_continues():
    campaigns = Path("app/services/campaigns.py").read_text()
    db = Path("app/db/__init__.py").read_text()
    assert "except errors.SlowModeWaitError as exc" in campaigns
    assert "_put_destination_on_waitlist" in campaigns
    assert "GROUP MESSAGE LIMIT — SKIPPING THIS TARGET" in campaigns
    assert "continue with the next group; do not pause the campaign." in campaigns
    assert "retry_at" in db
    assert 'QueueJob.status == "WAITLIST"' in campaigns


def test_all_temporarily_waitlisted_targets_do_not_stop_controller():
    campaigns = Path("app/services/campaigns.py").read_text()
    assert '"reason": "DONE"' in campaigns
    assert "all_destination_count and waitlisted_ids" in campaigns
