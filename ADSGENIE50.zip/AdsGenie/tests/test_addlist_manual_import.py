from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_addlist_sync_never_joins_chats():
    source = (ROOT / "app" / "mtproto" / "addlists.py").read_text(encoding="utf-8")
    assert "CheckChatlistInviteRequest" in source
    assert "No chats were joined or imported automatically." in source
    assert "ImportChatInviteRequest" not in source
    assert "JoinChannelRequest" not in source

def test_addlist_is_configured_and_cli_option_uses_it():
    config = (ROOT / "app" / "config.py").read_text(encoding="utf-8")
    cli = (ROOT / "app" / "cli.py").read_text(encoding="utf-8")
    assert "https://t.me/addlist/WDpE-_NxRvI0OTlk" in config
    assert "from app.mtproto.addlists import sync_addlist" in cli

def test_cooldown_notifications_are_silent_but_sleep_remains():
    campaigns = (ROOT / "app" / "services" / "campaigns.py").read_text(encoding="utf-8")
    controller = (ROOT / "app" / "bots" / "controller.py").read_text(encoding="utf-8")
    assert "await asyncio.sleep(settings.batch_cooldown_seconds)" in campaigns
    assert "await asyncio.sleep(settings.batch_cooldown_seconds)" in controller
    assert "BATCH COOLDOWN" not in campaigns
    assert "AD CYCLE COMPLETE" not in controller

def test_delete_instance_menu_exists():
    cli = (ROOT / "app" / "cli.py").read_text(encoding="utf-8")
    assert "async def delete_instance" in cli
    assert 'print("16. Delete instance and its local session/log files")' in cli

def test_forum_message_links_include_topic_path():
    campaigns = (ROOT / "app" / "services" / "campaigns.py").read_text(encoding="utf-8")
    assert "topic_id=topic_id" in campaigns
    assert 'f"https://t.me/c/{internal_id}/{int(topic_id)}/{int(msg_id)}"' in campaigns
    assert "view_link=view_link" in campaigns
